# Neko X AI

Android chat app for the Neko X persona.

## Setup
1. Open the project in Android Studio.
2. Create `local.properties` in the project root and add:
   `NEKO_API_KEY=YOUR_API_KEY`
3. Sync Gradle.
4. Build the APK from Android Studio.

The app uses an OpenAI-compatible Chat Completions endpoint. Edit `ApiClient.kt` to change the endpoint/model for another provider.

Features: persistent local chat history, Neko X system persona, dark UI, API-based AI replies, clear-chat button.
